export const linkCli = ("http://localhost:7172/api/Cliente");
