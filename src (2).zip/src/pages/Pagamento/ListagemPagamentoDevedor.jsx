import React, { useEffect, useState } from "react";
import { linkPag } from "./linkPag";
import { linkCli } from "../Cliente/linkCli";
import { linkVen } from "../Venda/linkVen";
import "./Pagamento.css";


export function ListagemPagamentoDevedor() {

  return (
    <div className="centroListagemPagamentoDevedor">
      <div className="filtrosPagamentoDevedor">
        <label>Cliente:</label>
        <select >
          <option value="">Todos</option>
      
        </select>

        <label>Status:</label>
        <select>
          <option value="todos">Todos</option>
          <option value="pagas">Pagas</option>
          <option value="naopagas">Não pagas</option>
        </select>
      </div>

      <div className="tabelaCarteiraContainer">
        <h2>Parcelas em Carteira a Receber</h2>
        <table className="tabelaCarteira">
          <thead>
            <tr>
              <th>ID Venda</th>
              <th>Cliente</th>
              <th>Parcela</th>
              <th>Vencimento</th>
              <th>Valor Parcela</th>
              <th>Valor Pago</th>
              <th>Status</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
           
          </tbody>
          <tfoot>
            <tr>
              <td colSpan={4}>Totais:</td>
              <td><strong>R$ </strong></td>
              <td><strong>R$ </strong></td>
              <td colSpan={2}><strong>A pagar: R$ </strong></td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}
