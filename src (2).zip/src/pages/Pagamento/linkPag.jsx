export const linkPag = ("http://localhost:7172/api/Pagamento");
