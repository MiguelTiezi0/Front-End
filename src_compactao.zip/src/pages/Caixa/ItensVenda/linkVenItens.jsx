export const linkVenItens = ("http://localhost:7172/api/Itens_Venda");
