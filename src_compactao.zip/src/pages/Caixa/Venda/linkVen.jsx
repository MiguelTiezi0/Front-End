export const linkVen = ("http://localhost:7172/api/Venda");
