export const Link_Itens_Compra = ("http://localhost:7172/api/Itens_Compra");
