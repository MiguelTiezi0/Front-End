export const linkFor = ("http://localhost:7172/api/Fornecedor");
