export const linkFun = ("http://localhost:7172/api/Funcionario");
