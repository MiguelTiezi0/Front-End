export const linkCat = ("http://localhost:7172/api/Categoria");
