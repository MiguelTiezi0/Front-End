﻿namespace TCC_2025.Models
{
    public class DtoFechamento
    {
        public decimal ValorFechamento { get; set; }
    }
}
