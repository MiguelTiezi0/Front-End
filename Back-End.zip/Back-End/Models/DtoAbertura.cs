﻿namespace TCC_2025.Models
{
    public class DtoAbertura
    {
        public decimal ValorAbertura { get; set; }
    }
}
